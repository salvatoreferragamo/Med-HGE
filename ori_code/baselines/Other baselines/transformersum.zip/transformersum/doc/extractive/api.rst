Extractive API Reference
========================

Model/Module
------------

.. automodule:: extractive

Data
----

.. automodule:: data

Pooling
-------

.. automodule:: pooling

Classifier
----------

.. automodule:: classifier

.. _convert_to_extractive_api:

Convert To Extractive
---------------------

.. automodule:: convert_to_extractive
