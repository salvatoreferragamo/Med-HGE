import json 
with open('dev_v2.json','r',encoding='utf-8') as r_f:
    json_data = json.load(r_f)
    for id, (k,sample) in enumerate(json_data.items()):
        for sum in sample["report"]:
            summary = ''     
            for kk,vv in sum.items():
                summary += kk + '：' + vv.strip()
            with open('imcs_dev.jsonl', mode='a+', encoding='utf8') as f:
                data = {}
                data['conversation_id'] = id
                data['conversation'] = []
                data['conversation'].append({})
                dialogue = '请将下述对话总结生成摘要：\n'
                for utt in sample['dialogue']:         
                    dialogue += utt['speaker'] + '：' + utt['sentence'].strip().replace(' ','') + '\n'
                
                data['conversation'][0]['human'] = dialogue.strip()

                json.dump(data, f, ensure_ascii=False)
                f.write('\n')